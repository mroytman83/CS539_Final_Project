# rock-climbing-hold-classifier > 2023-12-10 10:51pm
https://universe.roboflow.com/rockclimbingholdclassifier-2yrpe/rock-climbing-hold-classifier

Provided by a Roboflow user
License: CC BY 4.0

